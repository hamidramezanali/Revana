import { useState } from "react";

type IconName =
  | "arrow-left"
  | "arrow-right"
  | "camera"
  | "check"
  | "chevron-down"
  | "heart"
  | "lamp"
  | "layers"
  | "scan"
  | "sparkles"
  | "swatch"
  | "texture"
  | "thumb-down"
  | "thumb-up"
  | "x";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    "arrow-left": <><path d="m15 18-6-6 6-6" /><path d="M9 12h11" /></>,
    "arrow-right": <><path d="m9 18 6-6-6-6" /><path d="M4 12h11" /></>,
    camera: <><path d="M14.5 5 13 3h-2L9.5 5H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2Z" /><circle cx="12" cy="12" r="3.5" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    "chevron-down": <path d="m6 9 6 6 6-6" />,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
    lamp: <><path d="M8 14h8l-1-9H9l-1 9Z" /><path d="M12 14v6M9 20h6" /></>,
    layers: <><path d="m12 2 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 17l9 5 9-5" /></>,
    scan: <><path d="M3 9V5a2 2 0 0 1 2-2h4M15 3h4a2 2 0 0 1 2 2v4M21 15v4a2 2 0 0 1-2 2h-4M9 21H5a2 2 0 0 1-2-2v-4" /><path d="M7 12h10" /></>,
    sparkles: <><path d="m12 3-1.2 3.8L7 8l3.8 1.2L12 13l1.2-3.8L17 8l-3.8-1.2L12 3Z" /><path d="m19 15-.7 2.3L16 18l2.3.7L19 21l.7-2.3L22 18l-2.3-.7L19 15Z" /></>,
    swatch: <><circle cx="12" cy="12" r="9" /><path d="M12 3a9 9 0 0 0 0 18c1.4 0 2-1.8.9-2.7-.8-.7-.3-2 .8-2H16a5 5 0 0 0 5-5C21 6.7 17 3 12 3Z" /><circle cx="8" cy="9" r=".8" /><circle cx="12" cy="7" r=".8" /><circle cx="16" cy="9" r=".8" /></>,
    texture: <><path d="M4 4h16v16H4z" /><path d="m4 9 5-5M4 15 15 4M5 20 20 5M11 20l9-9M17 20l3-3" /></>,
    "thumb-down": <><path d="M17 14V3M7 14l3 7c.8 0 2-.5 2-2v-5h5a2 2 0 0 0 2-2l-1-7a2 2 0 0 0-2-2H8a3 3 0 0 0-3 2l-2 6a2 2 0 0 0 2 3h2Z" /><path d="M17 4h3v9h-3" /></>,
    "thumb-up": <><path d="M17 10v11M7 10l3-7c.8 0 2 .5 2 2v5h5a2 2 0 0 1 2 2l-1 7a2 2 0 0 1-2 2H8a3 3 0 0 1-3-2l-2-6a2 2 0 0 1 2-3h2Z" /><path d="M17 20h3v-9h-3" /></>,
    x: <><path d="m6 6 12 12M18 6 6 18" /></>,
  };
  return (
    <svg aria-hidden="true" fill="none" height={size} viewBox="0 0 24 24" width={size}>
      <g stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.7">{paths[name]}</g>
    </svg>
  );
}

function Button({
  children,
  className = "",
  icon,
  onClick,
}: {
  children: React.ReactNode;
  className?: string;
  icon?: IconName;
  onClick?: () => void;
}) {
  return (
    <button className={`button ${className}`} onClick={onClick} type="button">
      <span>{children}</span>{icon && <Icon name={icon} size={18} />}
    </button>
  );
}

const photos = {
  empty: "https://images.unsplash.com/photo-1630699376106-d550afb865bd?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  warm: "https://images.unsplash.com/photo-1554995207-c18c203602cb?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  modular: "https://images.unsplash.com/photo-1758957701419-2c6e266f7988?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  leather: "https://images.unsplash.com/photo-1632829882891-5047ccc421bc?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  curved: "https://images.unsplash.com/photo-1680503397667-3877494708a1?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  green: "https://images.unsplash.com/photo-1632119580908-ae947d4c7691?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  dark: "https://images.unsplash.com/photo-1615529179035-e760f6a2dcee?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
  classic: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1080",
};

const views = [
  { short: "Scan", title: "Scan your empty room" },
  { short: "Taste", title: "Discover your taste" },
  { short: "Budget", title: "Set budget & priorities" },
  { short: "Directions", title: "Explore complete solutions" },
  { short: "Sofa", title: "Choose the anchor sofa" },
  { short: "Lighting", title: "Choose the next layer" },
  { short: "Tips", title: "Designer guidance" },
  { short: "Recipe", title: "Color & material plan" },
  { short: "Finish", title: "Your room plan" },
];

function PhoneHeader({ step, title, light = false }: { step: number; title: string; light?: boolean }) {
  return (
    <>
      <div className={`status-bar ${light ? "status-light" : ""}`}><span>9:41</span><span>● ● ◒</span></div>
      <div className={`phone-header ${light ? "status-light" : ""}`}>
        <Icon name="arrow-left" size={20} />
        <span className="phone-header-title">{title}</span>
        <span className="step-count">{step}/9</span>
      </div>
    </>
  );
}

function ScanView() {
  return (
    <div className="screen scan-screen">
      <img alt="Empty room being measured with the phone camera" className="scan-photo" src={photos.empty} />
      <div className="scan-shade" />
      <PhoneHeader light step={1} title="Scan empty room" />
      <div className="scan-copy">
        <span className="eyebrow light">Room capture</span>
        <div className="scan-title">Move slowly around<br />your space</div>
        <p>Start with the room empty. We’ll map every wall, opening and outlet.</p>
      </div>
      <div className="scan-frame">
        <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
        <div className="measure horizontal"><span>5.2 m</span></div>
        <div className="measure vertical"><span>2.7 m</span></div>
        <div className="window-tag">Window · 1.8 m</div>
        <div className="door-tag">Door</div>
      </div>
      <div className="scan-progress"><span /><p>68% captured</p></div>
      <div className="camera-row">
        <span className="round-tool"><Icon name="layers" /></span>
        <span className="shutter"><span /></span>
        <span className="round-tool"><Icon name="camera" /></span>
      </div>
    </div>
  );
}

const tasteCards = [
  { label: "Soft & natural", image: photos.warm },
  { label: "Clean & sculptural", image: photos.curved },
  { label: "Rich & collected", image: photos.classic },
  { label: "Calm & minimal", image: photos.modular },
  { label: "Bold & expressive", image: photos.green },
  { label: "Moody & tailored", image: photos.dark },
];

function TasteView() {
  const [selected, setSelected] = useState([0, 2, 3]);
  const toggle = (index: number) => setSelected((items) => items.includes(index) ? items.filter((item) => item !== index) : [...items, index]);
  return (
    <div className="screen">
      <PhoneHeader step={2} title="Your taste" />
      <div className="content taste-content">
        <span className="eyebrow">Quick visual test</span>
        <div className="screen-title">Which rooms feel like you?</div>
        <p className="screen-subtitle">Don’t think about style names. Pick the spaces you’d love to come home to.</p>
        <div className="taste-grid">
          {tasteCards.map((card, index) => (
            <button className={`taste-card ${selected.includes(index) ? "selected" : ""}`} key={card.label} onClick={() => toggle(index)} type="button">
              <img alt={card.label} src={card.image} />
              <span>{card.label}</span>
              {selected.includes(index) && <i><Icon name="check" size={14} /></i>}
            </button>
          ))}
        </div>
        <Button className="primary full" icon="arrow-right">See my style · {selected.length} picks</Button>
      </div>
    </div>
  );
}

function SelectRow({ label, value }: { label: string; value: string }) {
  return <div className="select-row"><span>{label}</span><strong>{value}</strong><Icon name="chevron-down" size={17} /></div>;
}

function SpaceView() {
  const [budget, setBudget] = useState("€8–15k");
  return (
    <div className="screen">
      <PhoneHeader step={3} title="Budget & room" />
      <div className="content">
        <span className="eyebrow">Keep suggestions realistic</span>
        <div className="screen-title">What feels comfortable to spend?</div>
        <p className="screen-subtitle">This is for the whole living room. You can change it later.</p>
        <div className="budget-options">
          {["Under €5k", "€5–8k", "€8–15k", "€15k+"].map((value) => (
            <button className={budget === value ? "active" : ""} key={value} onClick={() => setBudget(value)} type="button">{value}</button>
          ))}
        </div>
        <div className="budget-summary"><span>Selected room budget</span><strong>{budget}</strong><p>We’ll balance investment pieces with smart saves.</p></div>
        <div className="field-label">What matters most?</div>
        <div className="priority-row">
          <span className="active"><Icon name="heart" size={15} /> Comfort</span>
          <span><Icon name="layers" size={15} /> Durability</span>
          <span><Icon name="sparkles" size={15} /> Statement look</span>
        </div>
        <div className="room-summary">
          <img alt="Scanned empty living room" src={photos.empty} />
          <div><span>From your scan</span><strong>19.8 m² living room</strong><p>5.2 × 3.8 m · ceiling 2.7 m</p></div>
          <i><Icon name="check" size={16} /></i>
        </div>
        <SelectRow label="People using the room" value="2–4 people" />
        <SelectRow label="Need to keep" value="Nothing — starting empty" />
        <Button className="primary full" icon="arrow-right">Build my solutions</Button>
      </div>
    </div>
  );
}

function StyleResultView() {
  const [direction, setDirection] = useState(0);
  const directions = [
    { name: "Warm & relaxed", match: "92% match", image: photos.warm, price: "From €9.4k" },
    { name: "Soft sculptural", match: "86% match", image: photos.curved, price: "From €11.2k" },
    { name: "Natural contrast", match: "81% match", image: photos.green, price: "From €7.8k" },
  ];
  return (
    <div className="screen">
      <PhoneHeader step={4} title="Complete solutions" />
      <div className="content direction-content">
        <span className="eyebrow">Built from your answers</span>
        <div className="screen-title">Three ways your room could feel</div>
        <p className="screen-subtitle">Each direction is complete, fits the room and stays within your budget.</p>
        <div className="direction-list">
          {directions.map((item, index) => (
            <button className={direction === index ? "active" : ""} key={item.name} onClick={() => setDirection(index)} type="button">
              <img alt={`${item.name} complete room solution`} src={item.image} />
              <span><strong>{item.name}</strong><small>{item.match} · {item.price}</small></span>
              {direction === index && <i><Icon name="check" size={14} /></i>}
            </button>
          ))}
        </div>
        <div className="mini-tip"><Icon name="sparkles" /><p><strong>Recommended: {directions[direction].name}</strong><br />We’ll build it one choice at a time, starting with the sofa.</p></div>
        <Button className="primary full" icon="arrow-right">Start with the sofa</Button>
      </div>
    </div>
  );
}

const sofaOptions = [
  { name: "Cloud modular", meta: "Soft, flexible, family-friendly", image: photos.modular },
  { name: "Tailored leather", meta: "Structured, timeless, characterful", image: photos.leather },
  { name: "Sculptural curve", meta: "Organic, airy, conversation-led", image: photos.curved },
  { name: "Low lounge", meta: "Relaxed, minimal, deep seated", image: photos.warm },
];

function TryOnView() {
  const [sofa, setSofa] = useState(0);
  const [reaction, setReaction] = useState<"up" | "down" | null>(null);
  const change = (direction: number) => setSofa((sofa + direction + sofaOptions.length) % sofaOptions.length);
  const current = sofaOptions[sofa];
  const react = (value: "up" | "down") => {
    setReaction(value);
    if (value === "down") setTimeout(() => {
      change(1);
      setReaction(null);
    }, 450);
  };
  return (
    <div className="screen try-screen">
      <PhoneHeader light step={5} title="Choose your sofa" />
      <img alt={`${current.name} shown in the room`} className="try-photo" src={current.image} />
      <div className="try-gradient" />
      <div className="ar-badge"><Icon name="scan" size={15} /> Tap furniture to edit</div>
      <button aria-label="Edit sofa" className="edit-furniture" type="button"><span>Sofa</span><Icon name="sparkles" size={14} /></button>
      <button aria-label="Previous sofa" className="image-arrow left" onClick={() => change(-1)} type="button"><Icon name="arrow-left" /></button>
      <button aria-label="Next sofa" className="image-arrow right" onClick={() => change(1)} type="button"><Icon name="arrow-right" /></button>
      <div className="sofa-count">{sofa + 1} of {sofaOptions.length}</div>
      <div className="sofa-sheet">
        <div className="drag" />
        <div className="sofa-heading"><div><span>Different shape · same room</span><strong>{current.name}</strong><p>{current.meta} · €2,490</p></div><button aria-label="Save sofa" type="button"><Icon name="heart" /></button></div>
        <div className="fit-row"><span><Icon name="check" size={15} /> Right scale</span><span><Icon name="check" size={15} /> 82 cm walkway</span><span><Icon name="check" size={15} /> Style match</span></div>
        <div className="rating-row">
          <button className={reaction === "down" ? "active dislike" : ""} onClick={() => react("down")} type="button"><Icon name="thumb-down" /> Not for me</button>
          <button className={reaction === "up" ? "active" : ""} onClick={() => react("up")} type="button"><Icon name="thumb-up" /> I like it</button>
        </div>
        <Button className="primary full" icon="arrow-right">Choose sofa · add lighting</Button>
      </div>
    </div>
  );
}

const lampOptions = [
  { name: "Arc floor lamp", note: "Adds height beside the low sofa", price: "€420", image: photos.warm },
  { name: "Paper globe", note: "Soft, diffused evening light", price: "€280", image: photos.modular },
  { name: "Sculptural tripod", note: "A stronger visual statement", price: "€560", image: photos.curved },
  { name: "Slim metal uplight", note: "Minimal footprint, warm glow", price: "€310", image: photos.dark },
  { name: "Ceramic table lamp", note: "Tactile light at eye level", price: "€190", image: photos.classic },
];

function LampView() {
  const [lamp, setLamp] = useState(0);
  const [feedback, setFeedback] = useState<Record<number, "up" | "down">>({});
  const current = lampOptions[lamp];
  const change = (direction: number) => setLamp((lamp + direction + lampOptions.length) % lampOptions.length);
  const rate = (value: "up" | "down") => {
    setFeedback((items) => ({ ...items, [lamp]: value }));
    if (value === "down") setTimeout(() => change(1), 350);
  };
  return (
    <div className="screen try-screen lamp-screen">
      <PhoneHeader light step={6} title="Next: lighting" />
      <img alt={`${current.name} in the designed room`} className="try-photo" src={current.image} />
      <div className="try-gradient" />
      <div className="sequence-pill"><span><Icon name="check" size={13} /> Sofa</span><b /><span className="active"><Icon name="lamp" size={13} /> Lamp</span><b /><span>Rug</span></div>
      <button aria-label="Previous lamp" className="image-arrow left" onClick={() => change(-1)} type="button"><Icon name="arrow-left" /></button>
      <button aria-label="Next lamp" className="image-arrow right" onClick={() => change(1)} type="button"><Icon name="arrow-right" /></button>
      <div className="lamp-marker"><Icon name="lamp" size={17} /><span>Best position</span></div>
      <div className="sofa-sheet lamp-sheet">
        <div className="drag" />
        <div className="sofa-heading"><div><span>Option {lamp + 1} of {lampOptions.length}</span><strong>{current.name}</strong><p>{current.note} · {current.price}</p></div></div>
        <div className="lamp-thumbs">
          {lampOptions.map((item, index) => <button aria-label={`View ${item.name}`} className={index === lamp ? "active" : ""} key={item.name} onClick={() => setLamp(index)} type="button"><img alt="" src={item.image} />{feedback[index] && <i><Icon name={feedback[index] === "up" ? "thumb-up" : "thumb-down"} size={11} /></i>}</button>)}
        </div>
        <div className="rating-row">
          <button className={feedback[lamp] === "down" ? "active dislike" : ""} onClick={() => rate("down")} type="button"><Icon name="thumb-down" /> Show another</button>
          <button className={feedback[lamp] === "up" ? "active" : ""} onClick={() => rate("up")} type="button"><Icon name="thumb-up" /> Keep this</button>
        </div>
        <Button className="primary full" icon="arrow-right">Choose lamp · continue</Button>
      </div>
    </div>
  );
}

function TipsView() {
  const [tip, setTip] = useState(0);
  const tips = [
    { title: "Create a visual landing point", body: "Group two cushions at one end and one contrasting cushion at the other. Odd numbers feel relaxed, not staged." },
    { title: "Add contrast, not more clutter", body: "A deep olive accent breaks up the beige field while staying inside your warm, natural palette." },
    { title: "Layer light at three heights", body: "Combine ceiling, eye-level and low ambient light. The floor lamp makes this corner feel intentional after dark." },
  ];
  return (
    <div className="screen">
      <PhoneHeader step={7} title="Finishing touches" />
      <div className="tips-photo-wrap">
        <img alt="Living room with interactive designer annotations" src={photos.warm} />
        <button aria-label="Cushion placement tip" className={`hotspot h1 ${tip === 0 ? "active" : ""}`} onClick={() => setTip(0)} type="button">1</button>
        <button aria-label="Color contrast tip" className={`hotspot h2 ${tip === 1 ? "active" : ""}`} onClick={() => setTip(1)} type="button">2</button>
        <button aria-label="Lighting tip" className={`hotspot h3 ${tip === 2 ? "active" : ""}`} onClick={() => setTip(2)} type="button">3</button>
      </div>
      <div className="content tip-content">
        <span className="eyebrow">Quick tip {tip + 1} of 3</span>
        <div className="tip-title">{tips[tip].title}</div>
        <p>{tips[tip].body}</p>
        <div className="sense-row">
          <span className="active"><Icon name="swatch" /> Color</span>
          <span><Icon name="texture" /> Texture</span>
          <span><Icon name="lamp" /> Light</span>
          <span><Icon name="layers" /> Shape</span>
        </div>
        <div className="expert-note"><Icon name="sparkles" /><p><strong>Why this works</strong><br />Wool, linen, timber and metal give the eye contrast without adding clutter.</p></div>
        <Button className="primary full" icon="arrow-right">Apply these tips</Button>
      </div>
    </div>
  );
}

function PaletteView() {
  return (
    <div className="screen">
      <PhoneHeader step={8} title="Your design recipe" />
      <div className="content palette-content">
        <span className="eyebrow">Balanced, not matched</span>
        <div className="screen-title">Color & material plan</div>
        <p className="screen-subtitle">A flexible guide for a room with depth. Percentages are a starting point, not a rigid rule.</p>
        <div className="palette-card">
          <div className="color-block base"><span>60%</span><strong>Warm oat</strong><small>Walls · rug · sofa</small></div>
          <div className="color-block secondary"><span>30%</span><strong>Deep olive</strong><small>Curtains · chair · art</small></div>
          <div className="color-block accent"><span>10%</span><strong>Burnt clay</strong><small>Cushions · objects</small></div>
        </div>
        <div className="field-label">Material mix</div>
        <div className="material-grid">
          <div className="material wood"><i /><strong>Oak</strong><span>warm structure</span></div>
          <div className="material linen"><i /><strong>Linen</strong><span>soft movement</span></div>
          <div className="material wool"><i /><strong>Wool</strong><span>cozy depth</span></div>
          <div className="material metal"><i /><strong>Metal</strong><span>fine contrast</span></div>
        </div>
        <div className="rule-card"><span>01</span><p><strong>Repeat each key material</strong><br />Use it in at least two places so the choice feels deliberate.</p></div>
        <div className="rule-card"><span>02</span><p><strong>Mix tactile finishes</strong><br />Pair matte linen and wool with a small amount of smooth metal or leather.</p></div>
        <Button className="primary full" icon="arrow-right">Add recipe to plan</Button>
      </div>
    </div>
  );
}

function FinishView() {
  return (
    <div className="screen">
      <PhoneHeader step={9} title="Your room plan" />
      <div className="finish-image">
        <img alt="Final warm modern living room plan" src={photos.warm} />
        <span><Icon name="sparkles" size={15} /> Ready to make real</span>
      </div>
      <div className="content finish-content">
        <div className="screen-title">A room that feels like you</div>
        <p className="screen-subtitle">Your scan, taste profile and designer rules are now one practical plan.</p>
        <div className="plan-list">
          <div><i><Icon name="scan" /></i><p><strong>Interactive 3D room</strong><span>Measurements & saved layout</span></p><Icon name="arrow-right" /></div>
          <div><i><Icon name="heart" /></i><p><strong>4 matched sofa options</strong><span>From modular to sculptural</span></p><Icon name="arrow-right" /></div>
          <div><i><Icon name="swatch" /></i><p><strong>Color & material recipe</strong><span>Palette, finishes & proportions</span></p><Icon name="arrow-right" /></div>
          <div><i><Icon name="sparkles" /></i><p><strong>7 designer actions</strong><span>Prioritized by visual impact</span></p><Icon name="arrow-right" /></div>
        </div>
        <Button className="primary full">Save project</Button>
        <Button className="secondary full">Open shopping list</Button>
      </div>
    </div>
  );
}

const screenComponents = [ScanView, TasteView, SpaceView, StyleResultView, TryOnView, LampView, TipsView, PaletteView, FinishView];

export default function App() {
  const [active, setActive] = useState(0);
  const Screen = screenComponents[active];
  const previous = () => setActive((active - 1 + views.length) % views.length);
  const next = () => setActive((active + 1) % views.length);
  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand"><span><Icon name="sparkles" size={19} /></span><strong>HABITAT</strong><i>AI interior studio</i></div>
        <div className="top-actions"><span>UX concept · 9 separate views</span><Button className="top-button">Share prototype</Button></div>
      </header>
      <div className="workspace">
        <aside className="sidebar">
          <div className="side-intro"><span>Experience map</span><strong>From room scan<br />to a confident choice</strong><p>Select any view to inspect it individually.</p></div>
          <nav aria-label="Prototype views">
            {views.map((view, index) => (
              <button className={index === active ? "active" : ""} key={view.short} onClick={() => setActive(index)} type="button">
                <i>{String(index + 1).padStart(2, "0")}</i>
                <span><strong>{view.short}</strong><small>{view.title}</small></span>
                {index === active && <Icon name="arrow-right" size={17} />}
              </button>
            ))}
          </nav>
          <div className="research-note"><Icon name="sparkles" /><p><strong>Design rationale</strong><br />Users choose images before seeing a style label, reducing vocabulary bias.</p></div>
        </aside>
        <section className="stage">
          <div className="stage-copy">
            <span>VIEW {String(active + 1).padStart(2, "0")} / {String(views.length).padStart(2, "0")}</span>
            <h1>{views[active].title}</h1>
            <p>{active === 4 ? "Use the arrows inside the view to compare genuinely different sofa silhouettes." : "A standalone, presentation-ready UX screen."}</p>
          </div>
          <div className="phone-wrap">
            <div className="phone"><Screen /></div>
            <div className="phone-shadow" />
          </div>
          <div className="stage-controls">
            <button aria-label="Previous view" onClick={previous} type="button"><Icon name="arrow-left" /></button>
            <div>{views.map((_, index) => <button aria-label={`Go to view ${index + 1}`} className={index === active ? "active" : ""} key={index} onClick={() => setActive(index)} type="button" />)}</div>
            <button aria-label="Next view" onClick={next} type="button"><Icon name="arrow-right" /></button>
          </div>
        </section>
        <aside className="detail-panel">
          <div><span className="detail-label">View purpose</span><p>{[
            "Capture a realistic empty shell: dimensions, windows, doors and outlets.",
            "Infer taste through instinctive image choices instead of style terminology.",
            "Set a realistic whole-room budget and decide what matters most.",
            "Compare complete design directions before selecting individual pieces.",
            "Tap the sofa, compare different forms and teach the system with feedback.",
            "Choose from five lighting alternatives, rating each suggestion in context.",
            "Explain professional design decisions directly on the user’s room.",
            "Build depth with a flexible color balance and contrasting textures.",
            "Turn inspiration into an actionable room and shopping plan.",
          ][active]}</p></div>
          <div><span className="detail-label">Key interaction</span><strong>{["Guided empty-room capture", "Multi-select image test", "Budget selection", "Solution comparison", "Sofa arrows & rating", "Five lamp options & rating", "Tap room hotspots", "Material recipe", "Save & shop"][active]}</strong></div>
          <div className="principle"><Icon name="check" /><p><strong>Evidence-informed</strong><br />The 60–30–10 color split is presented as a flexible heuristic. Multisensory design is framed around visual, tactile, light, acoustic and scent cues—not as a universal “five feelings” law.</p></div>
        </aside>
      </div>
    </main>
  );
}
